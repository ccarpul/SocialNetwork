package com.example.navigationdrawer.cursokotlingoogle.unit2

import kotlin.math.*


fun main() {
    val squareCabin = SquareCabin(5, 50.0)
    with(squareCabin) {
        println("\nSquare Cabin\n============")
        println("Capacity: ${capacity}")
        println("Material: ${buildingMaterial}")
        println("Has room? ${hasRoom()}")
        println("Área = ${floorArea()}")
    }

    val roundHut = RoundHut(3, 50.0)
    with(roundHut) {
        println("\nSquare Cabin\n============")
        println("Capacity: ${capacity}")
        println("Material: ${buildingMaterial}")
        println("Has room? ${hasRoom()}")
        println("Área = %.2f".format(floorArea()))
        println("Has room? ${hasRoom()}")
        getRoom()
        println("Has room? ${hasRoom()}")
        getRoom()
        println("Carpet size: ${calculateMaxCarpetSize()}")
    }

    val roundTower = RoundTower(4, 50.0, 2)

    with(roundTower) {
        println("\nRound Tower\n==========")
        println("Material: ${buildingMaterial}")
        println("Capacity: ${capacity}")
        println("Has room? ${hasRoom()}")
        println("Área = %.2f".format(floorArea()))
        println("Carpet size: ${calculateMaxCarpetSize()}")
    }
}

abstract class Dwelling(private var residents: Int) {

    abstract val buildingMaterial: String
    abstract val capacity: Int

    fun hasRoom(): Boolean = residents < capacity
    abstract fun floorArea(): Double

    fun getRoom() {
        if (capacity > residents) {
            residents++
            println("You got a room!")
        } else {
            println("Sorry, at capacity and no rooms left.")
        }
    }

}

class SquareCabin(residents: Int, private val length: Double) : Dwelling(residents) {

    override val buildingMaterial: String
        get() = "Wood"
    override val capacity: Int
        get() = 6

    override fun floorArea(): Double = length * length
}

open class RoundHut(residents: Int, private val radius: Double) : Dwelling(residents) {
    override val buildingMaterial: String
        get() = "Straw"
    override val capacity: Int
        get() = 4

    override fun floorArea(): Double = PI * radius.pow(2.0)

    fun calculateMaxCarpetSize(): Double {
        val diameter = 2 * radius
        return sqrt(diameter * diameter / 2)
    }

}

class RoundTower(
        residents: Int,
        radius: Double,
        private val floors: Int = 1
) : RoundHut(residents, radius) {

    override val buildingMaterial: String
        get() = "Stone"
    override val capacity: Int
        get() = 4 * floors

    override fun floorArea(): Double  =  super.floorArea() * floors
}





