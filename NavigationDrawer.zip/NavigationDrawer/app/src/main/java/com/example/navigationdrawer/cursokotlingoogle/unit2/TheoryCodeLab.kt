package com.example.navigationdrawer.cursokotlingoogle.unit2

import androidx.appcompat.app.AppCompatActivity

/**JERARQUÍA DE CLASES
 * De forma predeterminada, las clases de Kotlin son finales: no se pueden heredar. Para hacer
 * que una clase sea heredable, márquela con la openpalabra clave.
 * Referencia: https://kotlinlang.org/docs/reference/classes.html#inheritance
 * */

class Unit2CodeLab: AppCompatActivity(){
    override fun onResume() {
        super.onResume()
        val subClase1 = SubClase1("Katherine")
        println(subClase1.nombre)
        println(ClaseQuePuedeSerHeredada("Carlos").nombre)
    }
}

open class ClaseQuePuedeSerHeredada(open val nombre: String){

    init {
        println("Initializing Base $nombre")
    }
}

class ClaseQueNoPuedeSerHeredad{

}

class SubClase1(val name: String): ClaseQuePuedeSerHeredada(name){

    override val nombre = "$name -> Subclase1"
}

//class SubClase2: ClaseQueNoPuedeSerHeredad(){}

/**
If the derived class has a primary constructor, the base class can (and must) be initialized right
there, using the parameters of the primary constructor.

open class Base(p: Int)
class Derived(p: Int) : Base(p)

If the derived class has no primary constructor, then each secondary constructor has to initialize
the base type using the super keyword, or to delegate to another constructor which does that.
Note that in this case different secondary constructors can call different constructors
of the base type:

class MyView : View {

constructor(ctx: Context) : super(ctx)
constructor(ctx: Context, attrs: AttributeSet) : super(ctx, attrs)

}
 */

/**
Para miembros de funciones que se sobrescriben se tiene que declarar con el modificador open
y para sobrescribirlos en la clase que los implementa se declaran con el moificador overrider
 */

open class Shape {
    open fun draw() { /*...*/ }  //para permitir sobreescribir este metodo se declara open
    fun fill() { /*...*/ }
}

class Circle() : Shape() {
    override fun draw() { /*...*/ }  //para sobreescribirlo se declara override
    // fun fill(){}          //no se puede definir un método con el mismo nombre de
    // uno definido en la super clase nisiquiera si se le coloca en modifi-//cador override ya que requiere que en la superclase se declare como
    // override fun fill(){} //open
}

/**Una vez que se sobreescirbe un mètodo como dra() este sigue abierto desde la clase base o raíz.
 *para restringirlo en las siguientes subclases se declara con el modificador final
 *
 */

open class EjempliModificadorFinal: Shape(){  //esta clase es heredable ya que se decalro open
    final override fun draw() {}   // se coloca final para evitar que se siga sibreescribiendo
    // en las siguientes subclases
}

class HeredaDeClaseConMetodoFinal: EjempliModificadorFinal(){
    //override fun draw(){}  //No puede ser sobreescrito porque es declarado final en la supClase
}

/** Para llamar a una superClase se usa la palabra reservada Super*/
/** Para llamar a una superClase desde una clase interna se hace con super@ClaseExterna*/
/** si por ejemplo tengo una clase hija que hereda de una superclase y además impletanta un método
de una interfaz con el mismo nombre, este se tiene que especificar además de com la palabra super
el nombre de la superclase entre parentesis angulares super<SuperClase1>.metodo(),
super<SuperClase2>.metodo() Ejemplo:*/

open class Rectangle {
    open fun draw() { /* ... */ }
}

interface Polygon {
    fun draw() { /* ... */ } // interface members are 'open' by default
}

class Square() : Rectangle(), Polygon {
    // The compiler requires draw() to be overridden:
    override fun draw() {
        super<Rectangle>.draw() // call to Rectangle.draw()
        super<Polygon>.draw() // call to Polygon.draw()
    }
}


/** Clases abstractas*/

/** no es necesario llamar a super  en una clase hija ya que en Kotlin se estaría invocando
colocando los parentesis en la declaración de la clase hija -> ClaseHija: Abtrasta (){...}

Una clase "abstracta" es una clase de la que no se puede crear una instancia porque no está
completamente implementada. Puedes pensar en ello como un boceto. Un boceto incorpora las ideas
y los planes de algo, pero generalmente no tiene suficiente información para construirlo
 */

abstract class Abstract {

    abstract fun metodoAbstracto1()

    open fun metodoNormal(){
        println("Este es un mètodo normal")
    }
}

class ImplemetadorDeAbstract: Abstract(){
    override fun metodoAbstracto1() {
        TODO("Not yet implemented")
    }

    override fun metodoNormal() { //este método también se puede sobreescribir
        super.metodoNormal()
    }

}


/**Companion Onject*/

/** Son objeto que puedes declarar  dentro de una clase y puedes accesar a sus miembros a través del
nombre de la clase sin necesidad de crear una instancia de la clase que lo contiene*/

class MyClass {
    companion object Factory {
        fun create(): MyClass = MyClass()
    }
}
val instance = MyClass.create()