package com.example.navigationdrawer.cursokotlingoogle.unit2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.navigationdrawer.cursokotlingoogle.R

class CalculatorTip: AppCompatActivity(){

    lateinit var binding: ActivityMainBinding  //View Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        //setContentView(R.layout.tip_calculator)
    }
}