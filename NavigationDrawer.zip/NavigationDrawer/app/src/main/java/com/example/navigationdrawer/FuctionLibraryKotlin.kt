package com.example.navigationdrawer

import android.content.SharedPreferences
import android.util.Log
import androidx.appcompat.app.AppCompatActivity


class CourseKotlin : AppCompatActivity() {

    lateinit var sp: SharedPreferences.Editor
    val obj1: ArrayList<ModelContactsItem> = arrayListOf(
            ModelContactsItem("Sebrian", true)
    )
    val obj2: ArrayList<ModelContactsItem>? = arrayListOf(
            ModelContactsItem("Sabina", true),
            ModelContactsItem("Eliana", false)
    )
    var obj3: ArrayList<ModelContactsItem>? = null

    override fun onResume() {
        super.onResume()

        val applyVariable1 = obj1.apply {
            this[0].name = "Sebrian Lugo"
            println("inside block apply sin ${this.count()}")
        }

        val applyVariable2 = obj3?.apply {
            add(ModelContactsItem("funcion Apply", true))
            println("inside block apply con nulable")
        }
        println("applyVariable: ${applyVariable1.takeUnless { it.isNullOrEmpty()}?.get(0)?.name}" +
                "  applyVariable2: ${applyVariable2?.get(1)?.name ?: "return"}")
    }



    fun functionLibrary() {

        /**Todas estas funciones pueden ser usadas con objetos no nulables
        Sólo let y also puede trabajar con objetos nulables*/

        /**With la ultima expresion de lambda es la que se retorna
        sin embargo modifica el objeto que se pasa como parametro, es un lambda con receiver
        donde receiver en este caso es obj1 que se pasa como parametro y segundo paràmetro
        un bloque o lambda */
        val withVariable = with(obj1) {
            add(ModelContactsItem("funcion With", true))
            this[0].name
        }

        /**Run es igual a with solo que se llama como una funcion de extensión y por ende el receiver
        puede ser null , entonces se puede llamar con un safe call y se llama sólo si este
        receiver es no nulo.
        Aquí la ultima expresión del lambda es retornada
        si el receiver es nulo retorna null ya que no ejecuta el lambda que se pasa como parametro*/
        /**public inline fun <R> run(block: () → R): R */

        val runVariable1 = obj1.run {
            add(ModelContactsItem("funcion run", true))
            "last expresion runVariable1"
        }
        val runVariable2: String? = obj2?.run {
            println("inside run function con tipos nulables")
            this[0].name = "run con nulable"
            "last expresion runVariable2"

        }
        val runVariable3: String? = obj3?.run {
            println("inside run function con tipos nulables")
            this[0].name = "run con nulable"
            "last expresion runVariable3"

        }

        println("$runVariable1   $runVariable2 $runVariable3")

        /** |||Apply||| -> retorna el objeto modificado enviado como receiver en una funcion de extensión
        se invoca como una funcion de extensión donde el recever en este caso es obj1
        al igual que en run solo se llama el block pasado como lambda si es diferente de null el
        receiver*/
        /**public inline fun <T> T.apply(block: T.() → Unit): T
         * T: el tipo de dato la operacion principal (RECEIVER)
         * T.() quiere decir lambda con receiver que son como funciones de extension
         * el lambda retorna -> Unit
         * y se devuelve el receiver modificado :T
         * */

        val applyVariable1 = obj1[0].apply {
            name = "Sebrian Lugo"

            println("inside block apply sin nulable ${name.length}") //size refiere al tamaño del obj1
        }

        val applyVariable2 = obj3?.apply {
            add(ModelContactsItem("funcion Apply", true))
            println("inside block apply con nulable")
        }
        println("applyVariable: ${applyVariable1.name} applyVariable2: ${applyVariable2?.get(1)?.name ?: "return"}")

        /** |||ALSO||| Recibe una regular lambda, es decir difiere de apply porque apply recibe
        un lambda con receiver, en este caso it  se refiere al obj2*/
        /**public inline fun <T> T.also(block: (T) → Unit): T
         * T: el tipo de dato que llama la operación principal (RECEIVER)
         * (T) sería el lambda y se pasa como parametro el receiver principal
         * el lambda retorna -> Unit
         * y la función retorna el objeto modificado
         * */

        obj2.also {
            it?.add(ModelContactsItem("funcion also", true))
        }

        /**public inline fun <T, R> T.let(block: (T) → R): R
         * T corresponde al Receiver que llama la operacion principal
         * (T) recibe un lambda Regular permite trabajar con nulables, retorna null si
         *
         *
         * */

        obj2.let {
            it?.add(ModelContactsItem("funcion let", true))
            print(it?.count())

        }
    }
}

/** Tabla Resumen
 *
 *                        {.. this ..}               {.. it ..}
 *
 * return Result           with (T)                   T?.let
 * de lambda                T?.run
 *
 *
 *return Receiver           T?.apply T?.()                T?.also (T)
 *
 *
 * */


