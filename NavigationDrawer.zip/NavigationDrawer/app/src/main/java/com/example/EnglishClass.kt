package com.example

object Glossary{

    const val snippets = "Fragmentos / Retazos"
    const val thus = "Así / en consecuencia"
    const val carpet = "Alfombra"
    const val tip = "Propina"
    const val edge = "Borde"
    const val tidy = "Ordenado"
    const val statement = "declaración"
    const val encouraging = "alentador"
    const val rewards = "recompensa/Premio"


}