package com.example.navigationdrawer

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.util.Log
import java.util.*

class KotlinExercises : AppCompatActivity() {

    lateinit var prueba: String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        /** challenge 2 de hackerRank suma de elementos de un arreglo*//*
        val ar = arrayOf(1, 2, 3)
        var sum=0
        ar.forEach { sum += it }
        Log.i("Carpul", "onCreate: $sum")
        }
         */

        /**Challente 3, Comparar Tripletes*//*
        val a = arrayOf(4, 4, 4)
        val b = arrayOf(3, 2, 1)
        var c: IntArray = IntArray(2)
        val d = Array(2){
        }
        Log.i("Carpul", "d= ${d[0]}, ${d[1]}")

        for (i in a.indices) {
        if (a[i] > b[i]) c[0] += 1
        else if (a[i] < b[i]) c[1] += 1
        }
         */

        /**Convertidor de horas a hora militar*/

        /*
        var s = "12:50:11AM"

        s = if (s.contains("PM") && s.substring(0, 2) != "12") {
            s.replace(s.substring(0, 2), (12 + s.substring(0, 2).toInt()).toString())

        } else if (s.contains("AM") && s.substring(0, 2) == "12") {
            s.replace(s.substring(0, 2), "00")

        } else s

        s = s.replace(s.substring(8, 10), "")
        Log.i("Carpul", "$s")
        */

        /**Redondeo*//*

        var s= arrayOf(73, 67, 38, 33)
        var grades = IntArray(s.size)

        s.forEachIndexed { index, it ->
                if (it % 5 >= 3 && it >= 38)  grades[index] = it + 5 - (it % 5)
                else grades[index] = it
        }
*/

        /**Record de baloncesto*/ /*
        val scores = arrayOf(10, 22, 12, 16, 17, 8, 30, 20,28,27)
        var records = arrayOf(scores[0], scores[0])
        var countRecordUp = 0
        var countRecordDown = 0
        scores.forEach{ score ->

            if (records[0] < score) {
                records[0] = score
                ++countRecordUp
            }
            if (records[1] > score) {
                records[1] = score
                ++countRecordDown
            }
            Log.i("Carpul", "$countRecordUp $countRecordDown")
        }

*/

        /** Compra de dos articulos con un budget*//*
        val b = 20
        val kb = arrayOf(10, 12)
        val drive = arrayOf(1, 100, 8, 1000)
        var temp = -1
        kb.forEach { itemKb ->
            drive.forEach { itemDrive ->
                if (b >= temp && temp < itemDrive + itemKb && b >= itemDrive + itemKb) {
                    temp = itemKb + itemDrive

                }
            }
            if (temp==0) temp = -1
            Log.i("Carpul", "onCreate: $temp")
        }






        /**Manzanas y naranjas*//*

            val s = 5
        val t= 10
        val a= 3
        val b =15
            val apple = arrayOf(1,-2,3)
            val orange = arrayOf(1,-2,3)
            val range = s..t
            var countApple = 0
            var countOrange = 0

            apple.forEach{ if((it + a) in range) ++countApple }
            orange.forEach{ if((it + b) in range) ++countOrange }

            Log.i("Carpul", "$countApple \n $countOrange ")

        */

        /**Canguros*//*
        var x2 = (0..10).random()
        val v2 = (0..10).random()
        var x1 = (0..10).random()
        val v1 = (0..10).random()
        var temp = "Empty"

        Log.i("Carpul", "$x1 $v1 $x2 $v2")

        if(x1>x2 && v1<v2){
            while(x1>x2) {
                x2 += v2
                x1 += v1
                Log.i("Carpul", " $x1 $x2 ")
                temp = if(x1 == x2) "YES"
                else "NO"

            }

        }else if(x1<x2 && v1>v2) {
            while (x1 < x2) {
                x2 += v2
                x1 += v1
                Log.i("Carpul", "$x1 $x2 ")
                temp = if (x1 == x2) "YES"
                else "NO"
            }
        }
        else temp ="NO"
        Log.i("Carpul", "$temp")
*/

        /** bill*//*
        val k = (0..2).random()
        val bill = arrayOf((1..20).random(), (1..20).random(), (1..20).random())
        val b = (1..30).random()

        var total = 0
        Log.i("Carpul", "Bill: ${bill[0]} ${bill[1]} ${bill[2]}")
        Log.i("Carpul", "k $k")
        Log.i("Carpul", "b $b")
        bill.forEach { total += it }
        total = total.minus(bill[k])
        Log.i("Carpul", "${total/2}")

        if(total/2 == b) Log.i("Carpul", "Bon Apetit")
        else Log.i("Carpul", "${(total/2)-b}")
       */

        /**ordenar calcetines*//*
        var par = 0
        val ar = arrayOf((1..10).random(), (1..10).random(), (1..10).random(),
                (1..10).random(), (1..10).random(), (1..10).random(), (1..10).random(),  (1..10).random(),  (1..10).random())


        Arrays.sort(ar)
        Log.i("Carpul", "${ar[0]}, ${ar[1]}, ${ar[2]},${ar[3]}" +
                " ,${ar[4]}, ${ar[5]}, ${ar[6]}, ${ar[7]}, ${ar[8]}}")
            var cal: Int? = null
        var flag =0

            ar.forEach {

                if(cal == it) {
                    Log.i("Carpul", "par = $par")
                    if (par % 2 == 0) {
                        ++flag
                        Log.i("Carpul", " cal: $cal it: $it flag: $flag")
                    }
                    ++par
                }else{par =0}

                cal = it

            }
        Log.i("Carpul", "flag $flag")

*/

        /**Paginas de Libro*//*
        var count = .0
        var count2 = .0
        val p = (1..6).random()
        val n = (6..12).random()

        Log.i("Carpul", "pag = $p   libro $n")

        for (i in 2..p) ++count
        for (i in (p until n).reversed()) ++count2

        if (Math.round(count/2) < Math.round(count2/2)) {
            Log.i("Carpul", "${Math.round(count/2)}")
        }
        else {
            if(n%2 == 0) Log.i("Carpul", "${Math.round(count2/2)}")
            else Log.i("Carpul", "${(count2/2).toInt()}")
        }*/

        /** topografia*//*

        var count = 0
        val ar = "DDUDDUUUUUUUUU"

        ar.forEach {
            if(it=='D') --count
            else{
                count++
                if(count == 0) Log.i("Carpul", "Valle")
            }

        }*/

        /**cat and mouse position*/
/*
        val x = (1..10).random()
        val y = (1..10).random()
        val z  = (1..10).random()

        Log.i("Carpul", "$x $y $z")
        when {
            (x-z).absoluteValue == (y-z).absoluteValue -> Log.i("Carpul", "Mouse C")
            (x-z).absoluteValue <= (y-z).absoluteValue -> Log.i("Carpul", "Cat A")
            else -> Log.i("Carpul", "Cat B")
        }

*/

        val s = arrayOf(arrayOf(4,8,2), arrayOf(4,5,7), arrayOf(6,1,6))
        val f = IntArray(3)
        val c = IntArray(3)
        val d = IntArray(2)
        var prom = .0
        var flag = .0
        s.forEachIndexed() {i, array->
            array.forEach{ f[i] += it
            }
            for(index in array.indices){ c[i] += s[index][i] }
            d[0] += s[i][i]
            d[1] += s[i][s.lastIndex - i]
            flag += f[i] + c[i]
        }
        flag += d[0] + d[0]
        prom = flag / 8

        Log.i("Carpul", "falg $flag Promedio = $prom")



*/


        /**Velas mas altas de cumpleaños*/
        /*

            var count = 0

            fun birthdayCakeCandles(ar: Array<Int>): Int {

                Arrays.sort(ar)
                var temp = ar[ar.size]
                ar.forEach{
                    if (it== temp)
                        ++count

                }
                return count
            }
          */

        /** KOTLIN Member Reference bound*/

        class Person(val name: String, val age: Int) {
            fun isOlder(ageLimit: Int) = age > ageLimit

            fun equis() = ::isOlder
        }

        val alice = Person("Alice", 29)

        //Doing with Lambdas
        //val agePredicate: (Person, Int) -> Boolean =
        //       { alice: Person, ageLimit: Int -> alice.isOlder(ageLimit) }

        // Doing with member reference unbounds
        // val agePredicate: (Person, Int) -> Boolean = Person::isOlder


        // Doing with member reference bounds
        //val agePredicate: (Int) -> Boolean = alice::isOlder
        //Doing with Lambdas
        // val agePredicate: (Int) -> Boolean = { ageLimit: Int -> alice.isOlder(ageLimit) }

        // val predicate = alice.equis()
        //Log.i("Carpul", "onCreate: ${agePredicate(30)}, $predicate")

    }

    override fun onResume() {
        super.onResume()
        //masterMind()


    }
}

fun masterMind() {
    val s = Scanner(System.`in`)
    print("put first String")
    val t = s.nextInt()
    Log.i("Carpul", "MasterMind: $t")

    val firstName = "Carlos"

    firstName.forEach {
        Log.i("Carpul", "masterMind: ${firstName.length}")
    }

}

fun playWithMap() {

    val map = obj1.groupBy { it.isFavorite }
    println(map)
}

data class ModelContactsItem(var name: String, val isFavorite: Boolean)

val obj1: ArrayList<ModelContactsItem> = arrayListOf(
        ModelContactsItem("Sebrian", true),
        ModelContactsItem("Axel", false),
        ModelContactsItem("Coporo", true),
        ModelContactsItem("Ma", true),
        ModelContactsItem("Pa", false),
        ModelContactsItem("Sabina", true),
        ModelContactsItem("Eliana", false)
)
